<?php
$context = Timber::get_context();

Timber::render('templates/page.twig', $context);